import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ConsultaBooks extends JFrame {

    private static final long serialVersionUID = 1L;

    private JComboBox<String> consultas;
    private JTextField entrada;
    private JTextArea resultado;
    private Connection connection;

    public ConsultaBooks() {
        super("Consulta ao banco books");

        String[] opcoes = {
                "Todos os autores",
                "Livros de um autor",
                "Autores de um título",
                "Todos os títulos"
        };

        consultas = new JComboBox<>(opcoes);
        entrada = new JTextField(25);
        resultado = new JTextArea(20, 60);
        resultado.setEditable(false);

        JButton executar = new JButton("Executar");

        JPanel painel = new JPanel();
        painel.add(new JLabel("Consulta:"));
        painel.add(consultas);
        painel.add(new JLabel("Autor ou título:"));
        painel.add(entrada);
        painel.add(executar);

        add(painel, BorderLayout.NORTH);
        add(new JScrollPane(resultado), BorderLayout.CENTER);

        conectarBanco();

        executar.addActionListener((ActionEvent e) -> executarConsulta());

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(850, 500);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void conectarBanco() {
        try {
            // Conecta ao banco H2
            connection = DriverManager.getConnection("jdbc:h2:./books", "sa", "");

            Statement statement = connection.createStatement();

            // 1. Cria as tabelas caso elas ainda não existam
            statement.execute(
                    "CREATE TABLE IF NOT EXISTS authors (authorID INT AUTO_INCREMENT PRIMARY KEY, firstName VARCHAR(50), lastName VARCHAR(50))");
            statement.execute(
                    "CREATE TABLE IF NOT EXISTS titles (isbn VARCHAR(20) PRIMARY KEY, title VARCHAR(100), copyright VARCHAR(4))");
            statement.execute("CREATE TABLE IF NOT EXISTS authorISBN (authorID INT, isbn VARCHAR(20))");

            // 2. Verifica se a tabela está vazia. Se estiver, insere os dados de teste
            ResultSet rs = statement.executeQuery("SELECT COUNT(*) FROM authors");
            rs.next();
            if (rs.getInt(1) == 0) {
                // Inserindo Autores
                statement.execute("INSERT INTO authors (firstName, lastName) VALUES ('Paul', 'Deitel')");
                statement.execute("INSERT INTO authors (firstName, lastName) VALUES ('Harvey', 'Deitel')");

                // Inserindo Livros
                statement.execute(
                        "INSERT INTO titles (isbn, title, copyright) VALUES ('0133807800', 'Java How to Program', '2014')");
                statement.execute(
                        "INSERT INTO titles (isbn, title, copyright) VALUES ('0134289366', 'C++ How to Program', '2016')");

                // Relacionando (Qual autor escreveu qual livro)
                statement.execute("INSERT INTO authorISBN (authorID, isbn) VALUES (1, '0133807800')");
                statement.execute("INSERT INTO authorISBN (authorID, isbn) VALUES (2, '0133807800')");
                statement.execute("INSERT INTO authorISBN (authorID, isbn) VALUES (1, '0134289366')");
            }

            rs.close();
            statement.close();

            JOptionPane.showMessageDialog(
                    this,
                    "Conexão realizada! Tabelas e dados de teste criados com sucesso.");

        } catch (SQLException e) {
            e.printStackTrace();

            JOptionPane.showMessageDialog(
                    this,
                    "Erro ao conectar ao banco:\n\n" + e.toString());
        }
    }

    private void executarConsulta() {
        if (connection == null) {
            resultado.setText(
                    "Não foi possível executar a consulta.\n" +
                            "A conexão com o banco de dados não foi realizada.");
            return;
        }

        int opcao = consultas.getSelectedIndex();

        if (opcao == 0) {
            listarAutores();
        } else if (opcao == 1) {
            listarLivrosPorAutor();
        } else if (opcao == 2) {
            listarAutoresPorTitulo();
        } else if (opcao == 3) {
            listarTitulos();
        }
    }

    private void listarAutores() {
        String sql = "SELECT firstName, lastName " +
                "FROM authors " +
                "ORDER BY lastName, firstName";

        executarSQL(sql);
    }

    private void listarLivrosPorAutor() {
        String autor = entrada.getText();

        if (autor.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Digite o nome ou sobrenome do autor.");
            return;
        }

        String sql = "SELECT t.title, t.copyright, t.isbn " +
                "FROM authors a " +
                "INNER JOIN authorISBN ai ON a.authorID = ai.authorID " +
                "INNER JOIN titles t ON ai.isbn = t.isbn " +
                "WHERE a.firstName LIKE '%" + autor + "%' " +
                "OR a.lastName LIKE '%" + autor + "%' " +
                "ORDER BY a.firstName, a.lastName";

        executarSQL(sql);
    }

    private void listarAutoresPorTitulo() {
        String titulo = entrada.getText();

        if (titulo.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Digite o título do livro.");
            return;
        }

        String sql = "SELECT a.firstName, a.lastName " +
                "FROM authors a " +
                "INNER JOIN authorISBN ai ON a.authorID = ai.authorID " +
                "INNER JOIN titles t ON ai.isbn = t.isbn " +
                "WHERE t.title LIKE '%" + titulo + "%' " +
                "ORDER BY a.lastName, a.firstName";

        executarSQL(sql);
    }

    private void listarTitulos() {
        String sql = "SELECT title, copyright, isbn " +
                "FROM titles " +
                "ORDER BY title";

        executarSQL(sql);
    }

    private void executarSQL(String sql) {
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            ResultSetMetaData metaData = resultSet.getMetaData();

            int colunas = metaData.getColumnCount();

            resultado.setText("");

            for (int i = 1; i <= colunas; i++) {
                resultado.append(metaData.getColumnName(i) + "\t");
            }

            resultado.append("\n------------------------------------------------------------\n");

            while (resultSet.next()) {
                for (int i = 1; i <= colunas; i++) {
                    resultado.append(resultSet.getString(i) + "\t");
                }

                resultado.append("\n");
            }

            resultSet.close();
            statement.close();

        } catch (SQLException e) {
            e.printStackTrace();

            resultado.setText(
                    "Erro ao executar a consulta:\n\n" + e.toString());
        }
    }

    public static void main(String[] args) {
        new ConsultaBooks();
    }
}